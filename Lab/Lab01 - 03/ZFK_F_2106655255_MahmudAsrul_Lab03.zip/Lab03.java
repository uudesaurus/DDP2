import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;
/*
Name    : Mahmud Asrul
NPM     : 2106655255
Desc    : Program ini akan membuat playlist dengan memanfaatkan algoritma array. pemanfaat array di dalam koding dipakai menjadi 5 fungsi, yaitu membuat lagu
          next song, previous song, delete song, detail dari song tersebut.
*/

public class Lab03 {
    static int pointer = 0;
    static String[][] playlist = new String[1][4]; //masih belum nangkep kenapa [1][4], kenapa ngga [0][3]?
    static Scanner in = new Scanner(System.in);
    static int jumlahMusik = 0;                     //tujuan dari jumlahMusik adalah menghitung ada berapa musik dalam playlist
    static int musicIndexing = 0;                   //sebagai variable untuk menentukan row keberapa dari array terbarunya
                                                    //perbedaan signifikan dari musicIndexing dengan pointer adalah, musicIndexing untuk program, pointer untuk user.
    public static void main(String[] args) {
        //Algorithm 1.0
        addMusic();
        while (true){
            String userDecision;
            System.out.println("Lanjut menambahkan lagu?\n[1] Lanjut\n[0] Berhenti");
            System.out.print("Perintah : ");
            userDecision = in.nextLine();
            if (userDecision.equals("0")){
                break;
            } else if (userDecision.equals("1")) {
                addMusic();
                jumlahMusik++;
            } else {
                System.out.println("Maaf, command yang anda masukan salah");
                break;
        }
    
            }            
        
        System.out.println("Pacilfy siap dimulai");
               
        System.out.println("\nSELAMAT DATANG DI\n");
        System.out.println(" /$$$$$$$                     /$$ /$$  /$$$$$$");
        System.out.println("| $$__  $$                   |__/| $$ /$$__  $$");
        System.out.println("| $$  \\ $$ /$$$$$$   /$$$$$$$ /$$| $$| $$  \\__//$$   /$$");
        System.out.println("| $$$$$$$/|____  $$ /$$_____/| $$| $$| $$$$   | $$  | $$");
        System.out.println("| $$____/  /$$$$$$$| $$      | $$| $$| $$_/   | $$  | $$");
        System.out.println("| $$      /$$__  $$| $$      | $$| $$| $$     | $$  | $$");
        System.out.println("| $$     |  $$$$$$$|  $$$$$$$| $$| $$| $$     |  $$$$$$$");
        System.out.println("|__/      \\_______/ \\_______/|__/|__/|__/      \\____  $$");
        System.out.println("                                               /$$  | $$");
        System.out.println("                                              |  $$$$$$/");
        System.out.println("                                               \\______/");

        int command = 1;
        while (true){
            display();
            System.out.print("Command (0 untuk exit) : ");
            command = Integer.parseInt(in.nextLine());
            if (command == 1){
                prevMusic();
            }
            else if (command == 2){
                addMusic();
            }
            else if (command == 3){
                detailsMusic();
            }
            else if (command == 4){
                deleteMusic();
            }
            else if (command == 5){
                nextMusic();
            }
            else if (command == 0){
                break;
            }
            else {
                System.out.println("Maaf, command yang anda masukan salah");
            }
        }
        System.out.println("Terima kasih sudah menggunakan Pacilfy!");
        System.out.println(Arrays.deepToString(playlist));
    }

    private static void nextMusic() {
        if (pointer==playlist.length-1){
            pointer = 0;
        } else {
            pointer++;
        }
    }
    //menggunakana intstream untuk menghilangkan sesuai index yang sudah ditentukan dari pointer yang ada
    private static void deleteMusic() {
        if (playlist==null){
            System.out.println("Minimal harus ada satu lagu yang sudah di input");
        } else {
            IntStream.range(0, playlist.length)
            .filter(i -> i != pointer)
            .map(i -> pointer)
            .toArray();
        }


    }
    //Ketika sesuai dengan pointer yang di miliki
    //maka akan menjelaskan secara dari index yang udah di tentukan
    private static void detailsMusic() {
        System.out.println("Judul : " + playlist[pointer][0]);
        System.out.println("Artist : " + playlist[pointer][1]);
        System.out.println("Album : " + playlist[pointer][2]);
        System.out.println("Tahun : " + playlist[pointer][3]);
    }

    //Ketika prevmusic mencapai ujung diawal, 
    //maka akan diambil dari ujung akhir playlist.length, 
    //sehingga diambil lagu terakhirnya (-1 karena index mulai dari 0 sedangkan length mulai dari 1)
    private static void prevMusic() { 
        if (pointer==0){
            pointer = playlist.length-1;
        }else {
            pointer--;
        }
    }
    //Algoritma addMusic kali ini memanfaatkan penggunaan array yang bentukannya fixed size, dan di manfaatkan menggunakan
    //Jagged Algorithm untuk size
    private static void addMusic() {
        String[] musicArray = new String[4];
        System.out.println("Selamat Datang di Pacilfy!");
        System.out.println("Silakan masukkan lagu anda");
        System.out.print("Judul : ");
        musicArray[0] = in.nextLine();
        System.out.print("Artist : ");
        musicArray[1] = in.nextLine();
        System.out.print("Album : ");
        musicArray[2] = in.nextLine();
        System.out.print("Tahun : ");
        musicArray[3] = in.nextLine();
        musicIndexing=+1;
        
        if (jumlahMusik == 0){
            playlist[0]=musicArray;
        } else {
            String newPlaylist[][] = Arrays.copyOf(playlist, playlist.length+1);
            newPlaylist[musicIndexing]=musicArray;
            playlist = newPlaylist.clone();
            System.out.println(Arrays.deepToString(playlist));
        }
    }

    private static void display() {
        System.out.println();
        System.out.println("Currently Playing");

        String displayedMusic = " " + playlist[pointer][1] + " - " + playlist[pointer][0] + " ";
        String command = "|[1] prev |[2] add music |[3] details |[4] delete music |[5] next|";

        if (displayedMusic.length() < command.length()){
            int width = 62;
            String s = displayedMusic;

            int padSize = width - s.length();
            int padStart = s.length() + padSize / 2;

            s = String.format("%" + padStart + "s", s);
            s = String.format("%-" + width  + "s", s);


            System.out.println(new String(new char[66]).replace("\0", "="));
            System.out.println("= "+ s +" =");
            System.out.println(new String(new char[66]).replace("\0", "="));
            System.out.println(command);

            return;
        }
        System.out.println("=" + new String(new char[displayedMusic.length()]).replace("\0", "=") + "=");
        System.out.println("=" + displayedMusic + "=");
        System.out.println("=" + new String(new char[displayedMusic.length()]).replace("\0", "=") + "=");
        System.out.println(command);
    }   
}